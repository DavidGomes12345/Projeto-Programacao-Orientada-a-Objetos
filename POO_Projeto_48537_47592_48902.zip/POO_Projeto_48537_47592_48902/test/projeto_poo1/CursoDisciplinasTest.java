/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package projeto_poo1;

import java.util.ArrayList;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Utilizador
 */
public class CursoDisciplinasTest {
    
    public CursoDisciplinasTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of getCodigo method, of class CursoDisciplinas.
     */
    @Test
    public void testGetCodigo() {
        System.out.println("getCodigo");
        CursoDisciplinas instance = new CursoDisciplinas();
        String expResult = "";
        String result = instance.getCodigo();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setCodigo method, of class CursoDisciplinas.
     */
    @Test
    public void testSetCodigo() {
        System.out.println("setCodigo");
        String codigo = "";
        CursoDisciplinas instance = new CursoDisciplinas();
        instance.setCodigo(codigo);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getNomeCurso method, of class CursoDisciplinas.
     */
    @Test
    public void testGetNomeCurso() {
        System.out.println("getNomeCurso");
        CursoDisciplinas instance = new CursoDisciplinas();
        String expResult = "";
        String result = instance.getNomeCurso();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setNomeCurso method, of class CursoDisciplinas.
     */
    @Test
    public void testSetNomeCurso() {
        System.out.println("setNomeCurso");
        String nomeCurso = "";
        CursoDisciplinas instance = new CursoDisciplinas();
        instance.setNomeCurso(nomeCurso);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getDisciplinas method, of class CursoDisciplinas.
     */
    @Test
    public void testGetDisciplinas() {
        System.out.println("getDisciplinas");
        CursoDisciplinas instance = new CursoDisciplinas();
        ArrayList<DisciplinasEcts> expResult = null;
        ArrayList<DisciplinasEcts> result = instance.getDisciplinas();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setDisciplinas method, of class CursoDisciplinas.
     */
    @Test
    public void testSetDisciplinas() {
        System.out.println("setDisciplinas");
        ArrayList<DisciplinasEcts> disciplinas = null;
        CursoDisciplinas instance = new CursoDisciplinas();
        instance.setDisciplinas(disciplinas);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
