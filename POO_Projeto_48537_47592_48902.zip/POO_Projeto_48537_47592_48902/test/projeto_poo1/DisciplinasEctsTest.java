/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package projeto_poo1;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Utilizador
 */
public class DisciplinasEctsTest {
    
    public DisciplinasEctsTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of getLecionaLingua method, of class DisciplinasEcts.
     */
    @Test
    public void testGetLecionaLingua() {
        System.out.println("getLecionaLingua");
        DisciplinasEcts instance = new DisciplinasEcts();
        String expResult = "";
        String result = instance.getLecionaLingua();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setLecionaLingua method, of class DisciplinasEcts.
     */
    @Test
    public void testSetLecionaLingua() {
        System.out.println("setLecionaLingua");
        String lecionaLingua = "";
        DisciplinasEcts instance = new DisciplinasEcts();
        instance.setLecionaLingua(lecionaLingua);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getDisciplina method, of class DisciplinasEcts.
     */
    @Test
    public void testGetDisciplina() {
        System.out.println("getDisciplina");
        DisciplinasEcts instance = new DisciplinasEcts();
        String expResult = "";
        String result = instance.getDisciplina();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setDisciplina method, of class DisciplinasEcts.
     */
    @Test
    public void testSetDisciplina() {
        System.out.println("setDisciplina");
        String disciplina = "";
        DisciplinasEcts instance = new DisciplinasEcts();
        instance.setDisciplina(disciplina);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getEcts method, of class DisciplinasEcts.
     */
    @Test
    public void testGetEcts() {
        System.out.println("getEcts");
        DisciplinasEcts instance = new DisciplinasEcts();
        int expResult = 0;
        int result = instance.getEcts();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setEcts method, of class DisciplinasEcts.
     */
    @Test
    public void testSetEcts() {
        System.out.println("setEcts");
        int ects = 0;
        DisciplinasEcts instance = new DisciplinasEcts();
        instance.setEcts(ects);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
