/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package projeto_poo1;

import java.util.ArrayList;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Utilizador
 */
public class AlunoTest {
    
    public AlunoTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of toString method, of class Aluno.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        Aluno instance = new Aluno();
        String expResult = "";
        String result = instance.toString();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getDisciplinas method, of class Aluno.
     */
    @Test
    public void testGetDisciplinas() {
        System.out.println("getDisciplinas");
        Aluno instance = new Aluno();
        ArrayList<DisciplinasEcts> expResult = null;
        ArrayList<DisciplinasEcts> result = instance.getDisciplinas();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setDisciplinas method, of class Aluno.
     */
    @Test
    public void testSetDisciplinas() {
        System.out.println("setDisciplinas");
        ArrayList<DisciplinasEcts> disciplinas = null;
        Aluno instance = new Aluno();
        instance.setDisciplinas(disciplinas);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getPais method, of class Aluno.
     */
    @Test
    public void testGetPais() {
        System.out.println("getPais");
        Aluno instance = new Aluno();
        String expResult = "";
        String result = instance.getPais();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setPais method, of class Aluno.
     */
    @Test
    public void testSetPais() {
        System.out.println("setPais");
        String pais = "";
        Aluno instance = new Aluno();
        instance.setPais(pais);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getUni method, of class Aluno.
     */
    @Test
    public void testGetUni() {
        System.out.println("getUni");
        Aluno instance = new Aluno();
        String expResult = "";
        String result = instance.getUni();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setUni method, of class Aluno.
     */
    @Test
    public void testSetUni() {
        System.out.println("setUni");
        String uni = "";
        Aluno instance = new Aluno();
        instance.setUni(uni);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
