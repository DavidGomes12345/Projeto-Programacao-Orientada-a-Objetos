/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package projeto_poo1;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Utilizador
 */
public class DisciplinasEscolhidasTest {
    
    public DisciplinasEscolhidasTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of getCurso method, of class DisciplinasEscolhidas.
     */
    @Test
    public void testGetCurso() {
        System.out.println("getCurso");
        DisciplinasEscolhidas instance = null;
        int expResult = 0;
        int result = instance.getCurso();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setCurso method, of class DisciplinasEscolhidas.
     */
    @Test
    public void testSetCurso() {
        System.out.println("setCurso");
        int curso = 0;
        DisciplinasEscolhidas instance = null;
        instance.setCurso(curso);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getDisciplinas method, of class DisciplinasEscolhidas.
     */
    @Test
    public void testGetDisciplinas() {
        System.out.println("getDisciplinas");
        DisciplinasEscolhidas instance = null;
        String expResult = "";
        String result = instance.getDisciplinas();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setDisciplinas method, of class DisciplinasEscolhidas.
     */
    @Test
    public void testSetDisciplinas() {
        System.out.println("setDisciplinas");
        String disciplinas = "";
        DisciplinasEscolhidas instance = null;
        instance.setDisciplinas(disciplinas);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getTotalEcts method, of class DisciplinasEscolhidas.
     */
    @Test
    public void testGetTotalEcts() {
        System.out.println("getTotalEcts");
        DisciplinasEscolhidas instance = null;
        int expResult = 0;
        int result = instance.getTotalEcts();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setTotalEcts method, of class DisciplinasEscolhidas.
     */
    @Test
    public void testSetTotalEcts() {
        System.out.println("setTotalEcts");
        int totalEcts = 0;
        DisciplinasEscolhidas instance = null;
        instance.setTotalEcts(totalEcts);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
