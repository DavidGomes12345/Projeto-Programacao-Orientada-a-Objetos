/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package projeto_poo1;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Utilizador
 */
public class DisciplinasAddPrintTest {
    
    public DisciplinasAddPrintTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of adicionarDisciplinas method, of class DisciplinasAddPrint.
     */
    @Test
    public void testAdicionarDisciplinas() {
        System.out.println("adicionarDisciplinas");
        String alu = "";
        DisciplinasAddPrint.adicionarDisciplinas(alu);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of imprimirDisciplinas method, of class DisciplinasAddPrint.
     */
    @Test
    public void testImprimirDisciplinas() {
        System.out.println("imprimirDisciplinas");
        DisciplinasAddPrint.imprimirDisciplinas();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
