/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package projeto_poo1;

import java.util.ArrayList;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Utilizador
 */
public class ProfessorTest {
    
    public ProfessorTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of getEspecialidade method, of class Professor.
     */
    @Test
    public void testGetEspecialidade() {
        System.out.println("getEspecialidade");
        Professor instance = new Professor();
        String expResult = "";
        String result = instance.getEspecialidade();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setEspecialidade method, of class Professor.
     */
    @Test
    public void testSetEspecialidade() {
        System.out.println("setEspecialidade");
        String especialidade = "";
        Professor instance = new Professor();
        instance.setEspecialidade(especialidade);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getFuncao method, of class Professor.
     */
    @Test
    public void testGetFuncao() {
        System.out.println("getFuncao");
        Professor instance = new Professor();
        String expResult = "";
        String result = instance.getFuncao();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setFuncao method, of class Professor.
     */
    @Test
    public void testSetFuncao() {
        System.out.println("setFuncao");
        String funcao = "";
        Professor instance = new Professor();
        instance.setFuncao(funcao);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getProfessores method, of class Professor.
     */
    @Test
    public void testGetProfessores() {
        System.out.println("getProfessores");
        Professor instance = new Professor();
        ArrayList<String> expResult = null;
        ArrayList<String> result = instance.getProfessores();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setProfessores method, of class Professor.
     */
    @Test
    public void testSetProfessores() {
        System.out.println("setProfessores");
        ArrayList<String> professores = null;
        Professor instance = new Professor();
        instance.setProfessores(professores);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of toString method, of class Professor.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        Professor instance = new Professor();
        String expResult = "";
        String result = instance.toString();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
