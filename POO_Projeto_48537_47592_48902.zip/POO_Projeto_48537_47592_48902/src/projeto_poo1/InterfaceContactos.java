/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package projeto_poo1;

/** Interface 
 * @author DavidCristinaNuno <br><br>
 * Interface para mostrar os contactos
 */
public interface InterfaceContactos {
    public void listacontactos();
}
