
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package projeto_poo1;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Arrays;
import java.util.List;

/** Class main - Menu
 * @author DavidCristinaNuno <br><br>
 * Interação do user com o programa (menu)
 */
public class Projeto_POO1 {

    /**
     * @param args the command line arguments
     */ 
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String aux;
        
        int ects_inicial = 12;
        
        ArrayList<Integer> ECTS = new ArrayList<>(6);
        ECTS.add(20);
        ECTS.add(5);
        ECTS.add(3);
        ECTS.add(5);
        ECTS.add(2);
        ECTS.add(4);
        
        ArrayList<String> discOpcionais = new ArrayList<>(6);
        discOpcionais.add("Ingles");
        discOpcionais.add("Espanhol");
        discOpcionais.add("Alemao");
        discOpcionais.add("Frances");
        discOpcionais.add("Desenvolvimento Pessoal");
        discOpcionais.add("Gestao de tempo");
        
        ArrayList<String> cursosUni = new ArrayList<>(4);
        cursosUni.add("Informatica Web");
        cursosUni.add("Ciencias Farmaceuticas");
        cursosUni.add("Marketing");
        cursosUni.add("Gestao");
        
        ArrayList<String> discCurso = new ArrayList<>(4);
        discCurso.add("Programacao \n - Matematica I \n - Design I \n - Multimedia I \n - Empreendorismo e Inovacao");
        discCurso.add("Biologia Celular \n - Fisica Aplicada \n - Matemarica \n - Quimica \n - Estatistica");
        discCurso.add("Marketing \n - Direito do Consumo \n - Introducao a Gestao Financeira \n - Matematica para Gestao \n - Contabilidade Financeira I");
        discCurso.add("Auto-emprego \n - Gestor Financeiro \n - Controlo de Gestao \n - Ensino e Investigacao \n - Auditoria e Consultoria");
        //Inicialização de um ciclo.
        int op =9;
        while(op!=0)
        {   
            System.out.println();
            System.out.println("|---------------- Menu principal ----------------|");
            System.out.println("|                                                |");
            System.out.println("|  1. Registar Aluno                             |");
            System.out.println("|  2. Registar Professor                         |");
            System.out.println("|  3. Visualizar a lista de alunos               |");
            System.out.println("|  4. Visualizar a lista de professores          |");
            System.out.println("|  5. Inscricao Curso/Disciplina                 |");
            System.out.println("|  6. Visualizar Inscricoes Curso/Disciplina     |");
            System.out.println("|  7. Sugestoes de disciplinas                   |");  
            System.out.println("|  8. Contactos da Faculdade                     |");
            System.out.println("|  0. Fechar o Programa                          |");
            System.out.println("|                                                |");
            System.out.println("|------------------------------------------------|");
            System.out.println();
            System.out.println("Opcao: ");
            op = sc.nextInt();
            
            switch (op)
            {
                case 1 : 
                {
                    /*neste case fazemos a inscriçao do aluno e que vai adicionar 
                    ao ficheiro alunos.dat (basicamente servirá como uma BD*/
                    System.out.println("--------Inscricao do Aluno--------");
                    System.out.println(" - Digite o seu nome: ");
                    String n = sc.next();
                    System.out.println(" - Digite o seu ultimo nome: ");
                    String nu = sc.next();
                    System.out.println(" - Qual e o seu pais de origem: ");
                    String p = sc.next();
                    System.out.println(" - Qual e a sua universidade: ");
                    String u = sc.next();
                    System.out.println("-----------------------------------");
                    
                    Aluno a1 = new Aluno(n,nu,p,u);
                    //adiciona ao ficheiro alunos.dat
                    String al1= a1.getNome()+"     |     "+a1.getUltimonome()+"     |     "+a1.getPais()+"     |     "+a1.getUni()+"\n";
                    AlunoAddPrint addPrint = new AlunoAddPrint();
                    addPrint.adicionarAlunos(al1);
                    
                    break;
                
                }
                case 2 : 
                {
                    /*neste case fazemos a inscriçao do professor e vai adicionar 
                    ao ficheiro professor.dat (basicamente servirá como uma BD*/
                    System.out.println("--------Inscricao do Professor--------");
                    System.out.println(" - Digite o seu nome:");
                    String n = sc.next();
                    System.out.println(" - Digite o seu ultimo nome:");
                    String u =sc.next();
                    System.out.println(" - Qual e a sua especialidade:");
                    String e = sc.next();
                    System.out.println(" - Qual e a sua funcao:");
                    String f = sc.next();
                    System.out.println("--------------------------------------");
                                        
                    //adiciona ao ficheiro professor.dat
                    Professor p1 = new Professor(n,u,e,f);
                    String al1= p1.getNome()+"     |     "+p1.getUltimonome()+"     |     "+p1.getEspecialidade()+"     |     "+p1.getFuncao()+"\n";
           
                    ProfessorAddPrint addPrint = new ProfessorAddPrint();
                    addPrint.adicionarProfessores(al1);
                    break;
                }
                case 3 : {
                    //o utilizador ao selecionar a opção 3 irá-lhe ser apresentada a listagem dos alunos inscritos
                    System.out.println("--------------------------Lista de Alunos-------------------------------");
                    System.out.println("Nome     |     Ultimo Nome     |     Localizacao     |     Universidade ");
                    System.out.println("------------------------------------------------------------------------");
                        AlunoAddPrint addPrint = new AlunoAddPrint();
                        addPrint.imprimirAlunos();
                        break;
                }
                case 4 :{
                    //o utilizador ao selecionar a opção 3 irá-lhe ser apresentada a listagem dos professores inscritos
                    System.out.println("--------------------------Lista de Professores---------------------");
                    System.out.println("Nome     |     Ultimo Nome     |     Especialidade     |     Funcao");
                    System.out.println("-------------------------------------------------------------------");
                        ProfessorAddPrint addPrint = new ProfessorAddPrint();
                        addPrint.imprimirProfessores();
                        break;
                }
                case 5 : 
                {
                    int op2 =9;
                    while(op2!=0){
                            
                            /*Neste case o utilizador faz a inscrição ao curso pretendido. 
                            Irá ser mostrado as disiciplinas a que ficou inscrito e poderá ainda fazer a inscrição a mais disciplinas*/
                            System.out.println("--------Inscricao nos cursos da Faculdade--------");
                            System.out.println("|------------Inscricao Cursos------------|");
                            System.out.println("|                                        |");
                            System.out.println("|  1. Informatica Web                    |");
                            System.out.println("|  2. Ciencias Farmaceuticas             |");
                            System.out.println("|  3. Marketing                          |");
                            System.out.println("|  4. Gestao                             |");
                            System.out.println("|  0. Fechar                             |");
                            System.out.println("|                                        |");
                            System.out.println("|----------------------------------------|");
                            System.out.println();
                            
                            System.out.println(" - Confirme o seu nome");
                            String confnome = sc.next();
                            
                            System.out.println(" - Confirme o seu ultimo nome");
                            String confult = sc.next();
                            
                            System.out.println(" - Digite o numero do curso em que se pretende inscrever");
                            op2 = sc.nextInt();
                            
                            //mensagem nome do curso e respetivas disciplinas
                            mensagens(cursosUni.get(op2-1),discCurso.get(op2-1));
                                    
                            Scanner r3 = new Scanner(System.in);
                            aux = r3.nextLine();
                            String pequeno = aux.toLowerCase();//colocar o que a pessoa escreveu em minusculas
                            if (pequeno.equals("sim") || pequeno.equals("s"))
                            {
                                int escolhidas1;
                                //validar se escolherem mais do que 2 disciplinas
                                do{
                                    //mensagem disciplinas "opcionais"
                                    mensag();
                                    //disciplinas escolhidas até máximo de duas
                                    escolhidas1 = sc.nextInt();
                                    if (escolhidas1 > 2){
                                        System.out.println("Maximo de disciplinas opcionais sao duas!");
                                    }
                                }while (escolhidas1 > 2);
                                        
                                     
                                int t_Ects=ects_inicial;
                                
                                String disc[] = {"",""};
                                String discT="";
                                for (int i = 0 ; i < escolhidas1 ; i++){
                                    System.out.println(" - Digite o numero da disciplina pretendida");
                                    int escolhidas = sc.nextInt();
                                    int element = ECTS.get(escolhidas -1);
                                    //determinar se excede os 30 ECTS
                                    
                                    if ((t_Ects + element)<=30){
                                        t_Ects = t_Ects + element;
                                        disc[i]= discOpcionais.get(escolhidas-1);
                                        discT=discT + disc[i] + " ";
                                        System.out.println("Selecionou a disciplina: " + discOpcionais.get(escolhidas-1) );
                                        System.out.println("Inscreveu-se a um total de " + t_Ects + " ECTS.");
                                    }
                                    else{
                                        System.out.println("Tera de selecionar outra disciplina, esta excede os ECTS permitidos!");
                                        i--;
                                    }
                                            
                                }
                                DisciplinasEscolhidas esc = new DisciplinasEscolhidas(confnome,confult,op2,discT,t_Ects);
                                System.out.println(disc[0]+" "+disc[1]);
                                String el1= "   " + esc.getNome()+"     |     "+esc.getUltimonome()+"     |     "+ cursosUni.get(esc.getCurso()-1)+"     |     "+esc.getDisciplinas().toString()+"     |     "+ esc.getTotalEcts() +"\n";
                                DisciplinasEscolhidasAddPrint addPrint = new DisciplinasEscolhidasAddPrint(); 
                                addPrint.adicionarDisciplinasEscolhidas(el1);
                                           
                                mensag1(); 
                                op2=0;
                                
                            } else{
                                DisciplinasEscolhidas esc = new DisciplinasEscolhidas(confnome,confult,op2,null,ects_inicial);
                                String el1= "   " + esc.getNome()+"     |     "+esc.getUltimonome()+"     |     "+ cursosUni.get(esc.getCurso()-1)+"     |     "+esc.getDisciplinas()+"     |     "+ esc.getTotalEcts() +"\n";
                                DisciplinasEscolhidasAddPrint addPrint = new DisciplinasEscolhidasAddPrint(); 
                                addPrint.adicionarDisciplinasEscolhidas(el1);
                                mensag1();
                                op2=0;
                            }
                    }
                    break;
                }
                case 6:
                {
                    // Mostra a listagem das disciplinas e cursos
                    System.out.println("-----------------------------Lista de inscricoes-------------------------------------");
                    System.out.println("Primeiro Nome  |  Ultimo Nome  |  Curso  |  Disciplinas Escolhidas Opcionais  |  ECTS");
                    System.out.println("-------------------------------------------------------------------------------------");
                    DisciplinasEscolhidasAddPrint addPrint = new DisciplinasEscolhidasAddPrint();
                    addPrint.imprimirDisciplinasEscolhidas(); 
                    System.out.println();
                    break;
                }
                case 7 : 
                    
                    /*Neste case se o utilizador selecionar a (opção 1) pode fazer o registo de uma nova disciplinas incluindo os ECTS e a lingua,
                    se selecionar a (opção 2) pode ver listagem das disciplinas e dos ECTS. Se selecionar a opção 0 volta ao menu anterior.*/
                    
                {
                    //while(true)
                    int op1 =9;
                    while(op1!=0)
                    {
                        System.out.println("-------------------------------------------------------------------------------------");
                        System.out.println();
                        System.out.println("Aqui pode dar sugestoes de disciplinas que gostaria que a universidade tivesse.");
                        System.out.println();
                        System.out.println("|----------Disciplinas e cursos ---------|");
                        System.out.println("|                                        |");
                        System.out.println("|  1. Registo de Disciplinas e ECTS      |");
                        System.out.println("|  2. Listagem das disciplinas e ECTS    |");
                        System.out.println("|  0. Fechar                             |");
                        System.out.println("|                                        |");
                        System.out.println("|----------------------------------------|");
                        System.out.println();
                        System.out.println("Opcao: ");
                        op1 = sc.nextInt();
                        switch (op1)
                        {
                            case 1 : 
                            {
                                /*O utilizador faz o registo da disciplina e vai adicionar ao ficheiro disciplinas.dat 
                                (vai servir como uma BD*/
                                
                                System.out.println(" - Digite o nome da disciplina:");
                                String nd = sc.next();
                                System.out.println(" - Digite o numero de ECTS:");
                                int ne = sc.nextInt();
                                System.out.println(" - Em que lingua:(Portugues/Ingles/Misto)");
                                String l = sc.next();
                                DisciplinasEcts d1 = new DisciplinasEcts(nd,ne,l);
                                //adicionar ficheiro disciplinas.dat
                                String dl1= d1.getDisciplina()+"           |           "+d1.getEcts()+ "           |           " + d1.getLecionaLingua()+"\n";
                                DisciplinasAddPrint addPrint = new DisciplinasAddPrint();
                                addPrint.adicionarDisciplinas(dl1);
                                break;
                            }
                            case 2 : 
                            {
                                //mostra 
                                System.out.println("--------------------Lista de novos cursos ou disciplinas-------------------");
                                System.out.println("Disciplina/Curso     |     Numero de ECTS     |     Lingua                 ");
                                System.out.println("---------------------------------------------------------------------------");
                                DisciplinasAddPrint addPrint = new DisciplinasAddPrint();
                                addPrint.imprimirDisciplinas();   
                                break;
                            }
                            
                            case 0 : 
                            {   //o utilizador ao digitar 0, o programa vai voltar ao menu anterior!
                                op1=0;
                            }       
                        }  
                    }break;
                }
                case 0:
                {
                    break;
                }
                case 8:
                {
                    Contactos c1 = new Contactos();
                    c1.listacontactos();
                    break;
                }
            
            }
            
        }
    }
    //nome do curso e respetivas disciplinas
    public static void mensagens(String c, String d){
        System.out.println();
        System.out.println("Inscricao efetuada com sucesso ao curso - " + c);
        System.out.println();
        System.out.println("Neste momento esta inscrito as seguintes disciplinas: \n - " + d);
        System.out.println();
        System.out.println(" - Tem 12 ECTS. Gostaria de se inscrever a mais alguma disciplina? Sim/Nao");
    }
    //disciplinas "opcionais"
    public static void mensag(){
        System.out.println(" 1. Ingles (20 ECTS) \n 2. Espanhol (5 ECTS) \n 3. Alemao (3 ECTS) \n 4. Frances (5 ECTS) \n 5. Desenvolvimento Pessoal (2 ECTS) \n 6. Gestao de tempo (4 ECTS)");
        System.out.println();
        System.out.println(" - Quantas disciplinas se quer inscrever? (maximo 2)");
    }
    public static void mensag1(){
        System.out.println();
        System.out.println("--------------------------------------------------");
        System.out.println("Obrigado por se inscrever no nosso estabelecimento");
        System.out.println("--------------------------------------------------");
    }
}