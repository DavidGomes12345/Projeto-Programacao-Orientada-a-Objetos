/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projeto_poo1;

/** Mostrar contactos
 * @author DavidCristinaNuno <br><br>
 * Para este ficheiro mostrar os contactos terá de Herdar da interface (InterfaceContactos) o metódo 
 */
public class Contactos implements InterfaceContactos{
    public void listacontactos(){
        System.out.println("----------------Lista de Contactos---------------");
        System.out.println(" - Contacto dos servicos academicos: 967723452");
        System.out.println(" - Contacto do coordenador de Erasmus: 934643322");
        System.out.println(" - Contacto da universidade: 924884383");
        System.out.println("-------------------------------------------------");
    }
}
