/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projeto_poo1;

/** Classe abstrata - variáveis declaradas
 * @author DavidCristinaNuno <br><br>
 *  É uma classe abstrata que não pode ser utilizada para criar objetos.<br>
 *  Esta classe denomina-se por superclasse onde estarão as variáveis de instância que todas as outras classes vão herdar. <br>
 *  As classes que vão herdar as variáveis da superclasse denominam-se subclasse.
 */
public abstract class  Pessoa {
    private String ultimonome;
    private String nome;

    public Pessoa ()
    {
        nome = "";
        ultimonome="";
    }
    public Pessoa (String nome, String ultimonome)
    {
        this.nome = nome;
        this.ultimonome = ultimonome;
    }

    @Override
    public String toString() {
        return "Pessoa{" + "ultimonome=" + ultimonome + ", nome=" + nome + '}';
    }

    public String getUltimonome() {
        return ultimonome;
    }

    public void setUltimonome(String ultimonome) {
        this.ultimonome = ultimonome;
    }
   
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
}
