/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projeto_poo1;

import java.io.Serializable;
import java.util.ArrayList;

/** Declarar elementos base do professor
 * @author DavidCristinaNuno <br><br>
 * Elementos declarados: nome, especialidade e função. <br>
 * Para isso herdamos da classe abstrata (extends Pessoa) o nome e o último nome. 
 */
public class Professor extends Pessoa implements Serializable { 
    private String especialidade;
    private String funcao;
    private ArrayList<String> professores;
    
    public Professor()
    {
        especialidade = "";
        funcao = "";
    }
    
    public Professor(String nome, String ultimonome, String especialidade, String funcao)
    {
        super(nome,ultimonome);
        this.especialidade = especialidade;
        this.funcao = funcao;
    }
    
    /*public void adicionarprofs (String name, String lastname, String especialidade, String funcao)
    {
            professores.add( name);
            professores.add(lastname);
            professores.add(especialidade);
            professores.add(funcao);   
    }*/

    public String getEspecialidade() {
        return especialidade;
    }
    
    public void setEspecialidade(String especialidade) {
        this.especialidade = especialidade;
    }

    public String getFuncao() {
        return funcao;
    }

    public void setFuncao(String funcao) {
        this.funcao = funcao;
    }

    public ArrayList<String> getProfessores() {
        return professores;
    }

    public void setProfessores(ArrayList<String> professores) {
        this.professores = professores;
    }

    public String toString() {
        return super.toString()+" Especialidade: "+this.getEspecialidade()+" Função: "+this.getFuncao(); 
    }
}
