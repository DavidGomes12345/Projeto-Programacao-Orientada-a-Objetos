/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projeto_poo1;

import java.io.Serializable;
import java.util.ArrayList;

/** Registo de um novo aluno.
 * @author DavidCristinaNuno <br><br>
 * Uma vez que a classe Pessoa tem elementos em comum com a classe Aluno, <br>
 * a classe Aluno irá herdar alguns elementos da classe Pessoa (extends Pessoa).
 */

public class Aluno extends Pessoa implements Serializable{ //o Serializable é para podermos usar o file
    
    private String pais;
    private String uni;
    //guardar no aluno as disciplinas a que se inscrever
    private  ArrayList<DisciplinasEcts> disciplinas;
    
    @Override
    public String toString() {
        return super.toString()+" PAÍS: "+this.getPais()+" Universidade: "+this.getUni(); 
    }
  
    public Aluno()
    {
        pais = "";
        uni = "";
          
    }
    
    public Aluno (String nome, String ultimonome, String pais, String uni )
    {
        super(nome,ultimonome);
        this.pais = pais;
        this.uni = uni;  
        
    }

    public ArrayList<DisciplinasEcts> getDisciplinas() {
        return disciplinas;
    }

    public void setDisciplinas(ArrayList<DisciplinasEcts> disciplinas) {
        this.disciplinas = disciplinas;
    }
     
    
    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public String getUni() {
        return uni;
    }

    public void setUni(String uni) {
        this.uni = uni;
    }
       
    
}
