
package projeto_poo1;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

/** Adicionar nova Disciplina
 * @author DavidCristinaNuno <br><br>
 * Permite ao user inserir uma nova disciplina ao ficheiro disciplinas.dat; <br>
 * Permite imprimir a listagem das disciplinas no ecrã do user.
 */
public class DisciplinasAddPrint {
    static File ficheiro = new File("disciplinas.dat");

    public static void adicionarDisciplinas (String alu) {
    
        OutputStream os = null;
        try {
            // true permite adicionar
            os = new FileOutputStream(new File("disciplinas.dat"), true);
            os.write(alu.getBytes(), 0, alu.length());
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
		os.close();
            } catch (IOException e) {
		e.printStackTrace();
            }
	}

        
    }   
    public static void imprimirDisciplinas() 
    {
        FileInputStream fLer = null;
        try {
            fLer = new FileInputStream("disciplinas.dat");
            int i;
            char c;
            while((i=fLer.read())!=-1){
                c = (char) i;
                System.out.print(c);
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Projeto_POO1.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Projeto_POO1.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                fLer.close();
            } catch (IOException ex) {
                Logger.getLogger(Projeto_POO1.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
         
    }
}
