/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projeto_poo1;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

/** Adicionar alunos registados
 * @author DavidCristinaNuno <br><br>
 * Os alunos registados serão adicionados ao ficheiro alunos.dat; <br>
 * Permite imprimir a listagem dos alunos no ecrã do user. 
 */
public class AlunoAddPrint {
    static File ficheiro = new File("alunos.dat");

    public static void adicionarAlunos (String alu) {
    
        OutputStream os = null;
        try {
            // true permite adicionar
            os = new FileOutputStream(new File("alunos.dat"), true);
            os.write(alu.getBytes(), 0, alu.length());
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
		os.close();
            } catch (IOException e) {
		e.printStackTrace();
            }
	}

        
    }   
    public static void imprimirAlunos() 
    {
        FileInputStream fLer = null;
        try {
            fLer = new FileInputStream("alunos.dat");
            int i;
            char c;
            while((i=fLer.read())!=-1){
                c = (char) i;
                System.out.print(c);
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Projeto_POO1.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Projeto_POO1.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                fLer.close();
            } catch (IOException ex) {
                Logger.getLogger(Projeto_POO1.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
         
    }
}
