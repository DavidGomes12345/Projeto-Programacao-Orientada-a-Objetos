
package projeto_poo1;

import java.util.ArrayList;

/** Declarar elementos essenciais para a criação da disciplina
 * @author DavidCristinaNuno <br><br>
 * Elementos declarados: nome, código e o nome do curso à qual a disciplina pertence.
 */
public class CursoDisciplinas {
    private String codigo;
    private String nomeCurso;
    private  ArrayList<DisciplinasEcts> disciplinas;

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNomeCurso() {
        return nomeCurso;
    }

    public void setNomeCurso(String nomeCurso) {
        this.nomeCurso = nomeCurso;
    }

    public ArrayList<DisciplinasEcts> getDisciplinas() {
        return disciplinas;
    }

    public void setDisciplinas(ArrayList<DisciplinasEcts> disciplinas) {
        this.disciplinas = disciplinas;
    }  
    
}
