/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projeto_poo1;

import java.io.Serializable;

/** Escolha das Disciplinas extras
 * @author DavidCristinaNuno <br><br>
 * Disciplinas extras que o user pretende escolher. <br>
 * Serão guardadas para posteriormente poderem ser vistas segundo os ficheiros DisciplinasEscolhidasAddPrint.java e disciplinaescolhidas.dat
 */
public class DisciplinasEscolhidas extends Pessoa implements Serializable{
    
    private int curso;
    private String disciplinas;
    private int totalEcts;
    
    
    public int getCurso() {
        return curso;
    }

    public void setCurso(int curso) {
        this.curso = curso;
    }

    public String getDisciplinas() {
        return disciplinas;
    }

    public void setDisciplinas(String disciplinas) {
        this.disciplinas = disciplinas;
    }

    public int getTotalEcts() {
        return totalEcts;
    }

    public void setTotalEcts(int totalEcts) {
        this.totalEcts = totalEcts;
    }

    public DisciplinasEscolhidas(String nome, String ultimonome,int curso, String disciplinas, int totalEcts ) {
        super(nome, ultimonome);
        this.curso = curso;
        this.disciplinas = disciplinas;
        this.totalEcts = totalEcts;
    }
}
