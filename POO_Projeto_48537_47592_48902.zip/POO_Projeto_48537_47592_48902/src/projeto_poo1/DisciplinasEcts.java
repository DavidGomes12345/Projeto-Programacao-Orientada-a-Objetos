
package projeto_poo1;

/** Criação de uma nova Disciplina 
 * @author DavidCristinaNuno <br><br>
 * Nova Disciplica tem de ser criada com os respectivos Ects e a língua em que será lecionada.
 */
public class DisciplinasEcts {
    private String disciplina;
    private int ects;
    private String lecionaLingua;

    public String getLecionaLingua() {
        return lecionaLingua;
    }

    public void setLecionaLingua(String lecionaLingua) {
        this.lecionaLingua = lecionaLingua;
    }

    public String getDisciplina() {
        return disciplina;
    }

    public void setDisciplina(String disciplina) {
        this.disciplina = disciplina;
    }

    public int getEcts() {
        return ects;
    }

    public void setEcts(int ects) {
        this.ects = ects;
    }

    public DisciplinasEcts(String disciplina, int ects, String lecionaLingua) {
        this.disciplina = disciplina;
        this.ects = ects;
        this.lecionaLingua = lecionaLingua;
    }
    
    public DisciplinasEcts() {
        this.disciplina= "";
        this.lecionaLingua = "";
    }
    
            
}
