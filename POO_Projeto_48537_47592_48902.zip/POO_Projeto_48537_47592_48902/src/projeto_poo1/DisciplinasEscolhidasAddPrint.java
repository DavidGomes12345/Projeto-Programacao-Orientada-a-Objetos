/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projeto_poo1;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

/** Adicionar Diciplinas extras
 * @author DavidCristinaNuno <br><br>
 * Permite ao user inserir disciplinas extras ao ficheiro disciplinasescolhidas.dat; <br> 
 * Imprime a listagem das disciplinas escolhidas no ecrã do user.
 */
public class DisciplinasEscolhidasAddPrint {
    static File ficheiro = new File("disciplinasescolhidas.dat");

    public static void adicionarDisciplinasEscolhidas (String esc) {
    
        OutputStream os = null;
        try {
            // true permite adicionar
            os = new FileOutputStream(new File("disciplinasescolhidas.dat"), true);
            os.write(esc.getBytes(), 0, esc.length());
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
		os.close();
            } catch (IOException e) {
		e.printStackTrace();
            }
	}

        
    }   
    public static void imprimirDisciplinasEscolhidas() 
    {
        FileInputStream fLer = null;
        try {
            fLer = new FileInputStream("disciplinasescolhidas.dat");
            int i;
            char c;
            while((i=fLer.read())!=-1){
                c = (char) i;
                System.out.print(c);
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Projeto_POO1.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Projeto_POO1.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                fLer.close();
            } catch (IOException ex) {
                Logger.getLogger(Projeto_POO1.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
         
    }
}

