/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projeto_poo1;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

/** Registar um Professor
 * @author DavidCristinaNuno <br><br>
 * Permite ao user adicionar um professor ao ficheiro professores.dat; <br>
 * Imprime a listagem dos professores já registados no ecrã do user
 */
public class ProfessorAddPrint {
     static File ficheiro = new File("professores.dat");

    public static void adicionarProfessores (String prof) {
    
        OutputStream os = null;
        try {
            // true permite adicionar
            os = new FileOutputStream(new File("professores.dat"), true);
            os.write(prof.getBytes(), 0, prof.length());
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
		os.close();
            } catch (IOException e) {
		e.printStackTrace();
            }
	}

        
    }   
    public static void imprimirProfessores() 
    {
        FileInputStream fLer = null;
        try {
            fLer = new FileInputStream("professores.dat");
            int i;
            char c;
            while((i=fLer.read())!=-1){
                c = (char) i;
                System.out.print(c);
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Projeto_POO1.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Projeto_POO1.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                fLer.close();
            } catch (IOException ex) {
                Logger.getLogger(Projeto_POO1.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
         
    }
}
